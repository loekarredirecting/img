package com.demo.quiz.utils;

import android.content.Context;

import org.json.JSONObject;

import cn.tongdun.mobrisk.TDRisk;

public class DeviceUtils {
    public static String getHardwareId(Context context) {
        TDRisk.init(context);
        JSONObject deviceInfo = TDRisk.getBlackbox();
        String deviceId = deviceInfo.optString("device_id");
        JSONObject deviceRiskLabel = deviceInfo.optJSONObject("device_risk_label");

        if (deviceId.isEmpty() || deviceRiskLabel == null ||
                !deviceRiskLabel.optString("root").equals("false") ||
                !deviceRiskLabel.optString("debug").equals("false") ||
                !deviceRiskLabel.optString("multiple").equals("false") ||
                !deviceRiskLabel.optString("xposed").equals("false") ||
                !deviceRiskLabel.optString("magisk").equals("false") ||
                !deviceRiskLabel.optString("hook").equals("false") ||
                !deviceRiskLabel.optString("emulator").equals("false")
        ) return null;
        else return deviceId;
    }
}
