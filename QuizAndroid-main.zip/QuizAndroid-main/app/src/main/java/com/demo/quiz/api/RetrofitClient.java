package com.demo.quiz.api;

import com.demo.quiz.utils.Base91DecodeInterceptor;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

    //private static final String API_URL = "http://192.168.99.161:8000/api/v2/";
    private static final String API_URL = "https://freexwxwzzz.xyz/api/v2/";
    public static ApiService create(String uuid) {
        return new Retrofit.Builder()
                .baseUrl(API_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(buildOkHttpClient(uuid))
                .build()
                .create(ApiService.class);
    }

    private static OkHttpClient buildOkHttpClient(String uuid) {
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(chain -> {
            Request original = chain.request();
            Request request = original.newBuilder()
                    .header("uuid", uuid)
                    .method(original.method(), original.body())
                    .build();
            return chain.proceed(request);
        });
        httpClient.addInterceptor(new Base91DecodeInterceptor());

        return httpClient.build();
    }

}
