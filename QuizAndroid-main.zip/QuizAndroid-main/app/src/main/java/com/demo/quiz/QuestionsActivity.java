package com.demo.quiz;

import android.content.Intent;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.demo.quiz.adapters.QuestionPagerAdapter;
import com.demo.quiz.api.RetrofitClient;
import com.demo.quiz.databinding.ActivityQuestionsBinding;
import com.demo.quiz.models.Question;
import com.demo.quiz.models.QuestionGroup;
import com.demo.quiz.utils.TempAnswersStore;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class QuestionsActivity extends AppCompatActivity {

    public static final String EXTRA_QUESTION_GROUP = "question_group";
    private ActivityQuestionsBinding binding;
    private TempAnswersStore answersStore;
    public QuestionGroup questionGroup;
    private SoundPool soundPool;
    private int beepSoundId, buttonSoundId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityQuestionsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        questionGroup = getIntent().getParcelableExtra(EXTRA_QUESTION_GROUP);
        if (questionGroup == null) throw new RuntimeException();

        answersStore = new TempAnswersStore(this, questionGroup.id);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar == null) return;
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle(questionGroup.title);

        getQuestions();

        soundPool = new SoundPool.Builder()
                .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .build();
        beepSoundId = soundPool.load(this, R.raw.beep, 1);
        buttonSoundId = soundPool.load(this, R.raw.button, 1);

    }

    public void playBeepSound() {
        soundPool.play(beepSoundId, 1, 1, 0, 0, 1);
    }

    public void playButtonSound() {
        soundPool.play(buttonSoundId, 1, 1, 0, 0, 1);
    }

    @Override
    protected void onDestroy() {
        if (soundPool != null) soundPool.release();
        super.onDestroy();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) finish();
        return super.onOptionsItemSelected(item);
    }

    private void getQuestions() {
        RetrofitClient.create(MainActivity.DEVICE_ID)
                .getQuestions(questionGroup.id)
                .enqueue(new Callback<List<Question>>() {
                    @Override
                    public void onResponse(@NonNull Call<List<Question>> call, @NonNull Response<List<Question>> response) {
                        if (response.isSuccessful()) {
                            List<Question> questions = response.body();
                            if (questions != null && questions.size() > 0)
                                renderQuestions(questions);
                            else finish();
                        } else finish();
                    }

                    @Override
                    public void onFailure(@NonNull Call<List<Question>> call, @NonNull Throwable t) {
                        binding.progress.setVisibility(View.GONE);
                        Snackbar.make(binding.getRoot(), R.string.err_request_failed, Snackbar.LENGTH_INDEFINITE)
                                .setAction(R.string.btn_refresh, v -> getQuestions())
                                .show();
                    }
                });
    }

    private void renderQuestions(List<Question> questions) {
        ArrayList<Question> remainingQuestions = answersStore.getRemainingQuestions(questions);

        if (remainingQuestions.size() == 0) {
            Intent intent = new Intent(this, ResultActivity.class);
            intent.putExtra(ResultActivity.EXTRA_QUESTION_GROUP, questionGroup);
            startActivity(intent);
            finish();
        }

        binding.progress.setVisibility(View.GONE);
        binding.animBubble.setVisibility(View.VISIBLE);
        binding.animBubble.playAnimation();

        MainViewModel mainViewModel = new ViewModelProvider(this).get(MainViewModel.class);
        mainViewModel.fragmentPosition.observe(this, page -> binding.pager.setCurrentItem(page, true));

        QuestionPagerAdapter adapter = new QuestionPagerAdapter(this, mainViewModel, answersStore, remainingQuestions);
        binding.pager.setAdapter(adapter);
        binding.pager.setUserInputEnabled(false);
    }
}