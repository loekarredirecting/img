package com.demo.quiz.models;

import androidx.annotation.Keep;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

@Keep
public class UserAnswer {
    @Expose
    @SerializedName("question_id")
    public final Long questionId;

    @Expose
    @SerializedName("single_answer_id")
    public Long singleAnswerId;

    @Expose
    @SerializedName("plain_answer")
    public String plainAnswer;

    @Expose
    @SerializedName("multiple_answer_ids")
    public ArrayList<Long> multipleAnswerIds;

    public UserAnswer(Long questionId) {
        this.questionId = questionId;
    }

}