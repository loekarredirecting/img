package com.demo.quiz.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.AsyncListDiffer;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.demo.quiz.R;
import com.demo.quiz.databinding.ItemQuestionGroupBinding;
import com.demo.quiz.models.QuestionGroup;

public class QuestionGroupAdapter extends RecyclerView.Adapter<QuestionGroupAdapter.ViewHolder> {

    private final Context context;
    private final OnItemClickedListener listener;

    public QuestionGroupAdapter(Context context, OnItemClickedListener listener) {
        this.context = context;
        this.listener = listener;
    }

    public interface OnItemClickedListener {
        void onItemClicked(QuestionGroup questionGroup);
    }

    @NonNull
    @Override
    public QuestionGroupAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_question_group, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull QuestionGroupAdapter.ViewHolder holder, int position) {
        QuestionGroup questionGroup = asyncListDiffer.getCurrentList().get(position);
        holder.binding.ivAnswered.setVisibility(questionGroup.hasAnswered ? View.VISIBLE : View.GONE);
        holder.binding.tvTitle.setText(questionGroup.title);
        holder.binding.tvDescription.setText(questionGroup.description);
        holder.binding.tvDescription.setVisibility(questionGroup.description != null ? View.VISIBLE : View.GONE);
        holder.binding.tvInfo.setText(context.getString(R.string.msg_quiz_info, questionGroup.questionsCount, questionGroup.minCorrectness));
        holder.binding.getRoot().setEnabled(!questionGroup.hasAnswered);
        holder.binding.getRoot().setOnClickListener(v -> listener.onItemClicked(questionGroup));
    }

    @Override
    public int getItemCount() {
        return asyncListDiffer.getCurrentList().size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final ItemQuestionGroupBinding binding;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ItemQuestionGroupBinding.bind(itemView);
        }
    }

    private final DiffUtil.ItemCallback<QuestionGroup> diffUtil = new DiffUtil.ItemCallback<QuestionGroup>() {
        @Override
        public boolean areItemsTheSame(@NonNull QuestionGroup oldItem, @NonNull QuestionGroup newItem) {
            return oldItem.id == newItem.id;
        }

        @Override
        public boolean areContentsTheSame(@NonNull QuestionGroup oldItem, @NonNull QuestionGroup newItem) {
            return oldItem.equals(newItem);
        }
    };

    public final AsyncListDiffer<QuestionGroup> asyncListDiffer = new AsyncListDiffer<>(this, diffUtil);

}
