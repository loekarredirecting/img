package com.demo.quiz;

import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.demo.quiz.adapters.ResultAdapter;
import com.demo.quiz.api.RetrofitClient;
import com.demo.quiz.databinding.ActivityResultBinding;
import com.demo.quiz.databinding.DialogPrizeBinding;
import com.demo.quiz.models.AnswerEvaluation;
import com.demo.quiz.models.LuckyItem;
import com.demo.quiz.models.Prize;
import com.demo.quiz.models.QuestionGroup;
import com.demo.quiz.models.UserAnswer;
import com.demo.quiz.utils.ClipboardUtils;
import com.demo.quiz.utils.SpacingItemDecoration;
import com.demo.quiz.utils.TempAnswersStore;
import com.demo.quiz.views.PielView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Collections;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ResultActivity extends AppCompatActivity {

    public static final String EXTRA_QUESTION_GROUP = "question_group";
    private static final String[] greenColors = new String[]{"#90CAF9", "#64B5F6", "#42A5F5", "#2196F3", "#1E88E5", "#1976D2"};
    private ActivityResultBinding binding;
    private TempAnswersStore answersStore;

    private ArrayList<LuckyItem> luckyItems;
    private Prize selectedPrize;
    private SoundPool soundPool;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityResultBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setupViews();

        binding.btnPlay.setOnClickListener(v -> {
            binding.btnPlay.setEnabled(false);
            int targetIndex = findLuckyItemIndexById(luckyItems, selectedPrize.id);
            binding.luckyWheel.startLuckyWheelWithTargetIndex(targetIndex, PielView.SpinRotation.CLOCKWISE, false);
        });

        QuestionGroup questionGroup = getIntent().getParcelableExtra(EXTRA_QUESTION_GROUP);
        if (questionGroup == null) throw new RuntimeException();

        ActionBar actionBar = getSupportActionBar();
        if (actionBar == null) return;
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle(questionGroup.title);

        answersStore = new TempAnswersStore(this, questionGroup.id);
        submitAnswers(questionGroup.id, answersStore.answers);
    }

    private void submitAnswers(long questionGroupId, ArrayList<UserAnswer> answers) {
        RetrofitClient.create(MainActivity.DEVICE_ID)
                .submitAnswers(questionGroupId, answers)
                .enqueue(new Callback<AnswerEvaluation>() {
                    @Override
                    public void onResponse(@NonNull Call<AnswerEvaluation> call, @NonNull Response<AnswerEvaluation> response) {
                        if (response.isSuccessful()) {
                            AnswerEvaluation evaluation = response.body();
                            if (evaluation != null) renderEvaluation(evaluation);
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<AnswerEvaluation> call, @NonNull Throwable t) {
                        Snackbar.make(binding.getRoot(), R.string.err_request_failed, Snackbar.LENGTH_INDEFINITE)
                                .setAction(R.string.btn_refresh, v -> submitAnswers(questionGroupId, answers))
                                .show();
                    }
                });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) finish();
        return super.onOptionsItemSelected(item);
    }

    private void renderEvaluation(AnswerEvaluation evaluation) {
        MainActivity.shouldRefresh = true;
        answersStore.deleteAnswers();
        binding.animLoading.pauseAnimation();
        binding.animLoading.setVisibility(View.GONE);
        selectedPrize = evaluation.selectedPrize;

        if (evaluation.hasLotteryChance) {
            binding.btnPlay.setVisibility(View.VISIBLE);
            binding.luckyWheel.setVisibility(View.VISIBLE);
        }

        String msgAnswerStatistic = getString(R.string.msg_answer_statistic, evaluation.totalCount, evaluation.correctCount);
        msgAnswerStatistic += "\n" + getString((evaluation.hasLotteryChance ? R.string.msg_has_lottery_chance : R.string.msg_no_lottery_chance), evaluation.minCorrectness);

        binding.tvAnswerStatistic.setText(msgAnswerStatistic);

        ResultAdapter adapter = new ResultAdapter(this);
        binding.recycler.setAdapter(adapter);
        binding.recycler.addItemDecoration(new SpacingItemDecoration(getResources().getDimensionPixelSize(R.dimen.item_spacing), true));
        adapter.asyncListDiffer.submitList(evaluation.results);

        luckyItems = new ArrayList<>();
        int colorPosition = 0;
        for (Prize prize : evaluation.prizes) {
            LuckyItem luckyItem = new LuckyItem();
            luckyItem.id = prize.id;
            luckyItem.secondaryText = prize.title;
            luckyItem.color = Color.parseColor(greenColors[colorPosition]);
            luckyItems.add(luckyItem);
            colorPosition = (colorPosition == greenColors.length - 1) ? 0 : ++colorPosition;
        }
        Collections.shuffle(luckyItems);
        binding.luckyWheel.setData(luckyItems);
    }

    private int findLuckyItemIndexById(ArrayList<LuckyItem> items, long id) {
        for (int i = 0; i < items.size(); i++)
            if (items.get(i).id == id) return i;
        return 0;
    }

    private void setupViews() {
        binding.luckyWheel.setRound(10);
        binding.luckyWheel.setLuckyWheelTextColor(Color.WHITE);
        binding.luckyWheel.setTouchEnabled(false);
        binding.luckyWheel.setLuckyRoundItemSelectedListener(index -> showPrizeDialog());
    }

    private void copyToClipboard(String text) {
        ClipboardUtils.copy(this, text);
        Snackbar.make(binding.getRoot(), R.string.msg_copied_to_clipboard, Snackbar.LENGTH_SHORT).show();
    }

    private void showPrizeDialog() {
        DialogPrizeBinding prizeBinding = DialogPrizeBinding.inflate(getLayoutInflater());

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this)
                .setView(prizeBinding.getRoot())
                .setPositiveButton(android.R.string.ok, null);
        if (selectedPrize.prizeItem != null)
            builder.setNeutralButton(R.string.btn_copy, (dialog, which) -> copyToClipboard(selectedPrize.prizeItem.description));
        builder.show();

        prizeBinding.tvPrizeTitle.setText(selectedPrize.title);
        if (selectedPrize.prizeItem != null) {
            prizeBinding.tvPrizeItemTitle.setText(selectedPrize.prizeItem.title);
            prizeBinding.tvPrizeItemDescription.setText(selectedPrize.prizeItem.description);
            prizeBinding.anim.playAnimation();
            playWinPrizeSound();

            binding.prizeItemCard.setVisibility(View.VISIBLE);
            binding.tvPrizeItemTitle.setText(selectedPrize.prizeItem.title);
            binding.tvPrizeItemDescription.setText(selectedPrize.prizeItem.description);
            binding.tvPrizeItemDescription.setOnClickListener(v -> copyToClipboard(selectedPrize.prizeItem.description));
            binding.anim.playAnimation();
        } else {
            prizeBinding.tvPrizeItemTitle.setVisibility(View.GONE);
            prizeBinding.tvPrizeItemDescription.setVisibility(View.GONE);
            prizeBinding.anim.setVisibility(View.GONE);
        }
    }

    private void playWinPrizeSound() {
        soundPool = new SoundPool.Builder()
                .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .build();
        int winPrizeId = soundPool.load(this, R.raw.win_prize, 1);
        soundPool.setOnLoadCompleteListener((soundPool, sampleId, status) -> soundPool.play(winPrizeId, 1, 1, 0, 0, 1));
    }

    @Override
    protected void onDestroy() {
        if (soundPool != null) soundPool.release();
        super.onDestroy();
    }
}