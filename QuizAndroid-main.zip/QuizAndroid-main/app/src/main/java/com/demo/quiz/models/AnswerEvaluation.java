package com.demo.quiz.models;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.Keep;
import androidx.annotation.NonNull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;
import java.util.Objects;

@Keep
public class AnswerEvaluation implements Parcelable {

    @SerializedName("total_count")
    @Expose
    public long totalCount;
    @SerializedName("correct_count")
    @Expose
    public long correctCount;
    @SerializedName("min_correctness")
    @Expose
    public long minCorrectness;
    @SerializedName("has_lottery_chance")
    @Expose
    public boolean hasLotteryChance;
    @SerializedName("results")
    @Expose
    public List<Result> results;
    @SerializedName("selected_prize")
    @Expose
    public Prize selectedPrize;
    @SerializedName("prizes")
    @Expose
    public List<Prize> prizes;

    protected AnswerEvaluation(Parcel in) {
        totalCount = in.readLong();
        correctCount = in.readLong();
        minCorrectness = in.readLong();
        hasLotteryChance = in.readByte() != 0;
        results = in.createTypedArrayList(Result.CREATOR);
        selectedPrize = in.readParcelable(Prize.class.getClassLoader());
        prizes = in.createTypedArrayList(Prize.CREATOR);
    }

    public static final Creator<AnswerEvaluation> CREATOR = new Creator<AnswerEvaluation>() {
        @Override
        public AnswerEvaluation createFromParcel(Parcel in) {
            return new AnswerEvaluation(in);
        }

        @Override
        public AnswerEvaluation[] newArray(int size) {
            return new AnswerEvaluation[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeLong(totalCount);
        dest.writeLong(correctCount);
        dest.writeLong(minCorrectness);
        dest.writeByte((byte) (hasLotteryChance ? 1 : 0));
        dest.writeTypedList(results);
        dest.writeParcelable(selectedPrize, flags);
        dest.writeTypedList(prizes);
    }

    public static class Result implements Parcelable {

        @SerializedName("question")
        @Expose
        public String question;
        @SerializedName("answers")
        @Expose
        public List<String> answers;
        @SerializedName("evaluation")
        @Expose
        public boolean evaluation;

        protected Result(Parcel in) {
            question = in.readString();
            answers = in.createStringArrayList();
            evaluation = in.readByte() != 0;
        }

        public static final Creator<Result> CREATOR = new Creator<Result>() {
            @Override
            public Result createFromParcel(Parcel in) {
                return new Result(in);
            }

            @Override
            public Result[] newArray(int size) {
                return new Result[size];
            }
        };

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(@NonNull Parcel dest, int flags) {
            dest.writeString(question);
            dest.writeStringList(answers);
            dest.writeByte((byte) (evaluation ? 1 : 0));
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Result result = (Result) o;
            return question.equals(result.question);
        }

        @Override
        public int hashCode() {
            return Objects.hash(question);
        }
    }

}