package com.demo.quiz.models;

public class LuckyItem {
    public long id;
    public String topText;
    public String secondaryText;
    public int icon = 0;
    public int color;
}