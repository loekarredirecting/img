package com.demo.quiz.models;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.Keep;
import androidx.annotation.NonNull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Objects;

@Keep
public class QuestionGroup implements Parcelable {

    @SerializedName("id")
    @Expose
    public long id;
    @SerializedName("title")
    @Expose
    public String title;
    @SerializedName("description")
    @Expose
    public String description;
    @SerializedName("min_correctness")
    @Expose
    public long minCorrectness;
    @SerializedName("questions_count")
    @Expose
    public long questionsCount;
    @SerializedName("has_answered")
    @Expose
    public boolean hasAnswered;

    protected QuestionGroup(Parcel in) {
        id = in.readLong();
        title = in.readString();
        description = in.readString();
        minCorrectness = in.readLong();
        questionsCount = in.readLong();
        hasAnswered = in.readByte() != 0;
    }

    public static final Creator<QuestionGroup> CREATOR = new Creator<QuestionGroup>() {
        @Override
        public QuestionGroup createFromParcel(Parcel in) {
            return new QuestionGroup(in);
        }

        @Override
        public QuestionGroup[] newArray(int size) {
            return new QuestionGroup[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeLong(id);
        dest.writeString(title);
        dest.writeString(description);
        dest.writeLong(minCorrectness);
        dest.writeLong(questionsCount);
        dest.writeByte((byte) (hasAnswered ? 1 : 0));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        QuestionGroup that = (QuestionGroup) o;
        return id == that.id && hasAnswered == that.hasAnswered;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}