package com.demo.quiz.adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.demo.quiz.MainViewModel;
import com.demo.quiz.QuestionFragment;
import com.demo.quiz.models.Question;
import com.demo.quiz.utils.TempAnswersStore;

import java.util.ArrayList;

public class QuestionPagerAdapter extends FragmentStateAdapter {

    private final ArrayList<Fragment> fragments = new ArrayList<>();

    public QuestionPagerAdapter(@NonNull FragmentActivity fragmentActivity, MainViewModel mainViewModel, TempAnswersStore answersStore, ArrayList<Question> questions) {
        super(fragmentActivity);

        for (int i = 0; i < questions.size(); i++) {
            fragments.add(new QuestionFragment(i, mainViewModel, answersStore, questions.get(i), questions.size() - 1 > i));
        }
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        return fragments.get(position);
    }

    @Override
    public int getItemCount() {
        return fragments.size();
    }
}
