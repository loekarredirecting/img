package com.demo.quiz.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.AsyncListDiffer;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.demo.quiz.R;
import com.demo.quiz.databinding.ItemResultBinding;
import com.demo.quiz.models.AnswerEvaluation;

public class ResultAdapter extends RecyclerView.Adapter<ResultAdapter.ViewHolder> {

    private final Context context;
    private final @ColorInt int answerCorrectColor, answerWrongColor;

    public ResultAdapter(Context context) {
        this.context = context;
        answerCorrectColor = ContextCompat.getColor(context, R.color.answer_correct);
        answerWrongColor = ContextCompat.getColor(context, R.color.answer_wrong);
    }

    @NonNull
    @Override
    public ResultAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_result, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ResultAdapter.ViewHolder holder, int position) {
        AnswerEvaluation.Result result = asyncListDiffer.getCurrentList().get(position);
        holder.binding.tvTitle.setText(result.question);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(context, R.layout.item_result_item, R.id.tvText, result.answers);
        holder.binding.listView.setAdapter(adapter);
        holder.binding.getRoot().setCardBackgroundColor(result.evaluation ? answerCorrectColor : answerWrongColor);
    }

    @Override
    public int getItemCount() {
        return asyncListDiffer.getCurrentList().size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final ItemResultBinding binding;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ItemResultBinding.bind(itemView);
        }
    }

    private final DiffUtil.ItemCallback<AnswerEvaluation.Result> diffUtil = new DiffUtil.ItemCallback<AnswerEvaluation.Result>() {
        @Override
        public boolean areItemsTheSame(@NonNull AnswerEvaluation.Result oldItem, @NonNull AnswerEvaluation.Result newItem) {
            return oldItem.question.equals(newItem.question);
        }

        @Override
        public boolean areContentsTheSame(@NonNull AnswerEvaluation.Result oldItem, @NonNull AnswerEvaluation.Result newItem) {
            return oldItem.equals(newItem);
        }
    };

    public final AsyncListDiffer<AnswerEvaluation.Result> asyncListDiffer = new AsyncListDiffer<>(this, diffUtil);

}
