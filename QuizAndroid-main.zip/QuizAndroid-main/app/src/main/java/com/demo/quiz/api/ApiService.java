package com.demo.quiz.api;

import com.demo.quiz.models.AnswerEvaluation;
import com.demo.quiz.models.Question;
import com.demo.quiz.models.QuestionGroup;
import com.demo.quiz.models.UserAnswer;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface ApiService {

    @GET("question_groups")
    Call<List<QuestionGroup>> getQuestionGroups();

    @GET("question_groups/{question_group}")
    Call<List<Question>> getQuestions(@Path("question_group") long questionGroupId);

    @POST("question_groups/{question_group}")
    Call<AnswerEvaluation> submitAnswers(@Path("question_group") long questionGroupId, @Body List<UserAnswer> answers);
}
