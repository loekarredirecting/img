package com.demo.quiz.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.demo.quiz.models.Question;
import com.demo.quiz.models.UserAnswer;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class TempAnswersStore {

    private final SharedPreferences sharedPreferences;
    private final String key;

    public final ArrayList<UserAnswer> answers;

    public TempAnswersStore(Context context, Long questionGroupId) {
        this.key = String.format(Locale.ENGLISH, "question_group_%d", questionGroupId);
        this.sharedPreferences = context.getSharedPreferences("answers", Context.MODE_PRIVATE);

        Type type = new TypeToken<ArrayList<UserAnswer>>() {
        }.getType();

        ArrayList<UserAnswer> loadedAnswers;
        try {
            loadedAnswers = new Gson().fromJson(sharedPreferences.getString(key, null), type);
            loadedAnswers = loadedAnswers != null ? loadedAnswers : new ArrayList<>();
        } catch (Exception ignored) {
            loadedAnswers = new ArrayList<>();
        }
        this.answers = loadedAnswers;
    }

    public int addTemporaryAnswer(UserAnswer userAnswer) {
        answers.add(userAnswer);
        save();
        return answers.size() - 1;
    }

    public void updateAnswer(int index, UserAnswer answer) {
        answers.set(index, answer);
        save();
    }

    private void save() {
        sharedPreferences.edit().putString(this.key, new Gson().toJson(answers)).apply();
    }

    public void deleteAnswers() {
        sharedPreferences.edit().remove(this.key).apply();
    }

    private boolean isQuestionAnswered(Question question) {
        for (UserAnswer answer : answers)
            if (answer.questionId == question.id) return true;
        return false;
    }

    public ArrayList<Question> getRemainingQuestions(List<Question> questions) {
        ArrayList<Question> remainingQuestions = new ArrayList<>();
        for (Question question : questions)
            if (!isQuestionAnswered(question)) remainingQuestions.add(question);
        return remainingQuestions;
    }

}
