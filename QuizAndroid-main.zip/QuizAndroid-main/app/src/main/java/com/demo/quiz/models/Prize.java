package com.demo.quiz.models;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.Keep;
import androidx.annotation.NonNull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Objects;

@Keep
public class Prize implements Parcelable {

    @SerializedName("id")
    @Expose
    public long id;
    @SerializedName("title")
    @Expose
    public String title;
    @SerializedName("prize_item")
    @Expose
    public PrizeItem prizeItem;

    protected Prize(Parcel in) {
        id = in.readLong();
        title = in.readString();
        prizeItem = in.readParcelable(PrizeItem.class.getClassLoader());
    }

    public static final Creator<Prize> CREATOR = new Creator<Prize>() {
        @Override
        public Prize createFromParcel(Parcel in) {
            return new Prize(in);
        }

        @Override
        public Prize[] newArray(int size) {
            return new Prize[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeLong(id);
        dest.writeString(title);
        dest.writeParcelable(prizeItem, flags);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Prize prize = (Prize) o;
        return id == prize.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public static class PrizeItem implements Parcelable {

        @SerializedName("id")
        @Expose
        public long id;
        @SerializedName("prize_id")
        @Expose
        public long prizeId;
        @SerializedName("title")
        @Expose
        public String title;
        @SerializedName("description")
        @Expose
        public String description;

        protected PrizeItem(Parcel in) {
            id = in.readLong();
            prizeId = in.readLong();
            title = in.readString();
            description = in.readString();
        }

        public static final Creator<PrizeItem> CREATOR = new Creator<PrizeItem>() {
            @Override
            public PrizeItem createFromParcel(Parcel in) {
                return new PrizeItem(in);
            }

            @Override
            public PrizeItem[] newArray(int size) {
                return new PrizeItem[size];
            }
        };

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(@NonNull Parcel dest, int flags) {
            dest.writeLong(id);
            dest.writeLong(prizeId);
            dest.writeString(title);
            dest.writeString(description);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            PrizeItem prizeItem = (PrizeItem) o;
            return id == prizeItem.id;
        }

        @Override
        public int hashCode() {
            return Objects.hash(id);
        }
    }

}