package com.demo.quiz.utils;

import androidx.annotation.NonNull;

import java.io.IOException;
import java.util.Objects;

import okhttp3.Interceptor;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class Base91DecodeInterceptor implements Interceptor {
    @NonNull
    @Override
    public Response intercept(Chain chain) throws IOException {
        Response response = chain.proceed(chain.request());

        if (response.body() != null && response.headers().get("Content-Type") != null && response.isSuccessful() && Objects.equals(response.headers().get("Content-Type"), "application/json")) {
            String decodedString = new String(Base91.decode(response.body().string().getBytes()));
            ResponseBody decodedBody = ResponseBody.create(response.body().contentType(), decodedString);
            response = response.newBuilder().body(decodedBody).build();
        }

        return response;
    }
}