package com.demo.quiz.models;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.Keep;
import androidx.annotation.NonNull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;
import java.util.Objects;

@Keep
public class Question implements Parcelable {
    @SerializedName("id")
    @Expose
    public long id;
    @SerializedName("title")
    @Expose
    public String title;
    @SerializedName("type")
    @Expose
    public String type;
    @SerializedName("allowed_seconds")
    @Expose
    public long allowedSeconds;
    @SerializedName("answers")
    @Expose
    public List<Answer> answers;

    protected Question(Parcel in) {
        id = in.readLong();
        title = in.readString();
        type = in.readString();
        allowedSeconds = in.readLong();
        answers = in.createTypedArrayList(Answer.CREATOR);
    }

    public static final Creator<Question> CREATOR = new Creator<Question>() {
        @Override
        public Question createFromParcel(Parcel in) {
            return new Question(in);
        }

        @Override
        public Question[] newArray(int size) {
            return new Question[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeLong(id);
        dest.writeString(title);
        dest.writeString(type);
        dest.writeLong(allowedSeconds);
        dest.writeTypedList(answers);
    }

    public static class Type {
        public static final String SINGLE = "single";
        public static final String MULTIPLE = "multiple";
        public static final String PLAIN = "plain";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Question question = (Question) o;
        return id == question.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public static class Answer implements Parcelable {
        @SerializedName("id")
        @Expose
        public long id;
        @SerializedName("answer")
        @Expose
        public String answer;

        protected Answer(Parcel in) {
            id = in.readLong();
            answer = in.readString();
        }

        public static final Creator<Answer> CREATOR = new Creator<Answer>() {
            @Override
            public Answer createFromParcel(Parcel in) {
                return new Answer(in);
            }

            @Override
            public Answer[] newArray(int size) {
                return new Answer[size];
            }
        };

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(@NonNull Parcel dest, int flags) {
            dest.writeLong(id);
            dest.writeString(answer);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Answer answer = (Answer) o;
            return id == answer.id;
        }

        @Override
        public int hashCode() {
            return Objects.hash(id);
        }
    }
}