package com.demo.quiz;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.demo.quiz.adapters.QuestionGroupAdapter;
import com.demo.quiz.api.RetrofitClient;
import com.demo.quiz.databinding.ActivityMainBinding;
import com.demo.quiz.models.QuestionGroup;
import com.demo.quiz.utils.DeviceUtils;
import com.demo.quiz.utils.SpacingItemDecoration;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    public static String DEVICE_ID;
    private QuestionGroupAdapter adapter;
    public static boolean shouldRefresh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        DEVICE_ID = DeviceUtils.getHardwareId(this);
        if (DEVICE_ID == null) {
            new MaterialAlertDialogBuilder(this)
                    .setMessage(getString(R.string.msg_unsafe_env, getString(R.string.app_name)))
                    .setPositiveButton(android.R.string.ok, (dialog, which) -> finish())
                    .show();
        } else {
            setupViews();
            getQuestionGroups();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (shouldRefresh) getQuestionGroups();
    }

    private void setupViews() {
        adapter = new QuestionGroupAdapter(this, questionGroup -> {
            Intent intent = new Intent(MainActivity.this, QuestionsActivity.class);
            intent.putExtra(QuestionsActivity.EXTRA_QUESTION_GROUP, questionGroup);
            startActivity(intent);
        });
        binding.recycler.addItemDecoration(new SpacingItemDecoration(getResources().getDimensionPixelSize(R.dimen.item_spacing), true));
        binding.recycler.setAdapter(adapter);
        binding.swipe.setOnChildScrollUpCallback((parent, child) -> binding.recycler.canScrollVertically(-1));
        binding.swipe.setOnRefreshListener(this::getQuestionGroups);
    }

    private void getQuestionGroups() {
        shouldRefresh = false;
        binding.swipe.setRefreshing(true);

        RetrofitClient.create(DEVICE_ID)
                .getQuestionGroups()
                .enqueue(new Callback<List<QuestionGroup>>() {
                    @Override
                    public void onResponse(@NonNull Call<List<QuestionGroup>> call, @NonNull Response<List<QuestionGroup>> response) {
                        binding.swipe.setRefreshing(false);
                        if (response.isSuccessful())
                            adapter.asyncListDiffer.submitList(response.body(), () -> binding.recycler.scheduleLayoutAnimation());
                    }

                    @Override
                    public void onFailure(@NonNull Call<List<QuestionGroup>> call, @NonNull Throwable t) {
                        binding.swipe.setRefreshing(false);
                        Snackbar.make(binding.getRoot(), R.string.err_request_failed, Snackbar.LENGTH_INDEFINITE)
                                .setAction(R.string.btn_refresh, v -> getQuestionGroups())
                                .show();
                    }
                });
    }
}