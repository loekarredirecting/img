package com.demo.quiz;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class MainViewModel extends ViewModel {

    private final MutableLiveData<Integer> _fragmentPosition = new MutableLiveData<>();
    public LiveData<Integer> fragmentPosition = _fragmentPosition;

    public void setFragmentPosition(int position) {
        _fragmentPosition.setValue(position);
    }

}
