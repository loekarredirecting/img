package com.demo.quiz;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.demo.quiz.databinding.FragmentQuestionBinding;
import com.demo.quiz.databinding.ItemCheckboxBinding;
import com.demo.quiz.databinding.ItemRadioButtonBinding;
import com.demo.quiz.models.Question;
import com.demo.quiz.models.UserAnswer;
import com.demo.quiz.utils.TempAnswersStore;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

public class QuestionFragment extends Fragment {

    private final int index;
    private final MainViewModel mainViewModel;
    private final TempAnswersStore answersStore;
    private final Question question;
    private final boolean hasNextQuestion;

    private long selectedAnswerId = 0;
    private final ArrayList<Long> checkedAnswerIds = new ArrayList<>();
    private int storedAnswerIndex;
    private CountDownTimer countDownTimer;

    public QuestionFragment(int index, MainViewModel mainViewModel, TempAnswersStore answersStore, Question question, boolean hasNextQuestion) {
        this.index = index;
        this.mainViewModel = mainViewModel;
        this.answersStore = answersStore;
        this.question = question;
        this.hasNextQuestion = hasNextQuestion;
    }

    private FragmentQuestionBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentQuestionBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.tvTitle.setText(question.title);

        if (index == 0) startTimeoutProgress();

        mainViewModel.fragmentPosition.observe(getViewLifecycleOwner(), position -> {
            if (index == position) startTimeoutProgress();
        });

        binding.btnNext.setText(hasNextQuestion ? R.string.btn_next : R.string.btn_submit);
        binding.btnNext.setOnClickListener(v -> storeAnswer());

        renderQuestion();
    }

    private void startTimeoutProgress() {
        UserAnswer answer = new UserAnswer(question.id);
        storedAnswerIndex = answersStore.addTemporaryAnswer(answer);

        binding.progress.setMax((int) question.allowedSeconds);
        countDownTimer = new CountDownTimer(question.allowedSeconds * 1000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                long seconds = millisUntilFinished / 1000;
                binding.progress.setProgressCompat((int) seconds, true);
                if (seconds < 6) ((QuestionsActivity) requireActivity()).playBeepSound();
            }

            @Override
            public void onFinish() {
                proceedNext();
            }
        };
        countDownTimer.start();
    }

    private void renderQuestion() {
        switch (question.type) {
            case Question.Type.SINGLE:
                addRadioButtons(question.answers);
                break;

            case Question.Type.PLAIN:
                binding.edtLayout.setVisibility(View.VISIBLE);
                break;

            case Question.Type.MULTIPLE:
                addCheckboxes(question.answers);
                break;
        }
    }

    private void addRadioButtons(List<Question.Answer> answers) {
        binding.radioGroup.setVisibility(View.VISIBLE);
        LayoutInflater inflater = getLayoutInflater();
        for (Question.Answer answer : answers) {
            ItemRadioButtonBinding radioButtonBinding = ItemRadioButtonBinding.inflate(inflater, binding.getRoot(), false);
            radioButtonBinding.getRoot().setText(answer.answer);
            radioButtonBinding.getRoot().setTag(answer.id);
            radioButtonBinding.getRoot().setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) selectedAnswerId = (long) buttonView.getTag();
            });
            binding.radioGroup.addView(radioButtonBinding.getRoot());
        }
    }

    private void addCheckboxes(List<Question.Answer> answers) {
        LayoutInflater inflater = getLayoutInflater();
        for (Question.Answer answer : answers) {
            ItemCheckboxBinding itemCheckboxBinding = ItemCheckboxBinding.inflate(inflater, binding.getRoot(), false);
            itemCheckboxBinding.getRoot().setText(answer.answer);
            itemCheckboxBinding.getRoot().setTag(answer.id);
            itemCheckboxBinding.getRoot().setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) checkedAnswerIds.add((long) buttonView.getTag());
                else checkedAnswerIds.remove((long) buttonView.getTag());
            });
            binding.scrollBaseLayout.addView(itemCheckboxBinding.getRoot());
        }
    }

    private void storeAnswer() {
        ((QuestionsActivity) requireActivity()).playButtonSound();

        switch (question.type) {
            case Question.Type.SINGLE:
                if (selectedAnswerId == 0)
                    Snackbar.make(binding.getRoot(), R.string.msg_select_one_answer, Snackbar.LENGTH_SHORT).show();
                else {
                    UserAnswer answer = new UserAnswer(question.id);
                    answer.singleAnswerId = selectedAnswerId;
                    answersStore.updateAnswer(storedAnswerIndex, answer);
                    proceedNext();
                }
                break;

            case Question.Type.PLAIN:
                String plainAnswer = binding.edt.getEditableText().toString().trim();
                if (plainAnswer.isEmpty()) {
                    Snackbar.make(binding.getRoot(), R.string.msg_type_answer, Snackbar.LENGTH_SHORT).show();
                    binding.edtLayout.setError(getString(R.string.msg_type_answer));
                } else {
                    UserAnswer answer = new UserAnswer(question.id);
                    answer.plainAnswer = plainAnswer;
                    answersStore.updateAnswer(storedAnswerIndex, answer);
                    proceedNext();
                }
                break;

            case Question.Type.MULTIPLE:
                if (checkedAnswerIds.size() == 0)
                    Snackbar.make(binding.getRoot(), R.string.msg_select_at_least_one_answer, Snackbar.LENGTH_SHORT).show();
                else {
                    UserAnswer answer = new UserAnswer(question.id);
                    answer.multipleAnswerIds = checkedAnswerIds;
                    answersStore.updateAnswer(storedAnswerIndex, answer);
                    proceedNext();
                }
                break;
        }
    }

    private void proceedNext() {
        countDownTimer.cancel();
        if (hasNextQuestion) mainViewModel.setFragmentPosition(index + 1);
        else {
            Intent intent = new Intent(requireContext(), ResultActivity.class);
            intent.putExtra(ResultActivity.EXTRA_QUESTION_GROUP, ((QuestionsActivity) requireActivity()).questionGroup);
            startActivity(intent);
            requireActivity().finish();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}
